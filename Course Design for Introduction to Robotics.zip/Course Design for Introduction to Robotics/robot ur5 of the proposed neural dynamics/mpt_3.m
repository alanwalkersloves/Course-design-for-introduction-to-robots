
clear all;
format long;

global q0;
load mavn_SYSdata;
load mavn_SNDdata;

[Ppx,Ppy,Ppz]=position(q0);
ix=Ppx(7);iy=Ppy(7);iz=Ppz(7);
for jj=1:length(t)
   qjj=qAll(jj,:)';%simulated end effector position
   [Ppx,Ppy,Ppz]=position(qjj);
   j2px(jj,1)=Ppx(3);
   j3px(jj,1)=Ppx(4);
   j4px(jj,1)=Ppx(5);
   j5px(jj,1)=Ppx(6);
   posx(jj,1)=Ppx(7);%joint6
   j2py(jj,1)=Ppy(3);
   j3py(jj,1)=Ppy(4);
   j4py(jj,1)=Ppy(5);
   j5py(jj,1)=Ppy(6);
   posy(jj,1)=Ppy(7);%joint6
   j2pz(jj,1)=Ppz(3);
   j3pz(jj,1)=Ppz(4);
   j4pz(jj,1)=Ppz(5);
   j5pz(jj,1)=Ppz(6);
   posz(jj,1)=Ppz(7);%joint6
   %-------------------------------------------------
   dqjj=dqAll(jj,:)';%simulated end effector velocity
   [J,DJ]=jdj(qjj,dqjj);
   dpos=J*dqjj;
   dposx(jj,1)=dpos(1);
   dposy(jj,1)=dpos(2);
   dposz(jj,1)=dpos(3);
   ddqjj=ddqAll(jj,:)';%--joint torque--
   ddpos=J*ddqjj+DJ*dqjj;
   ddposx(jj,1)=ddpos(1);
   ddposy(jj,1)=ddpos(2);
   ddposz(jj,1)=ddpos(3);%simulated end-effector acceleration
   
   rx(jj,1)=0.3*(cos(2*t(jj))/25 + cos((4*t(jj))/3)/10)+ix-0.0420000000000000;
   ry(jj,1)=0.3*(sin(2*t(jj))/25 - (3*sin((4*t(jj))/3))/50)+iy;
   rz(jj,1)=iz;
   drx(jj,1)=0.3*(- (2*sin(2*t(jj)))/25 - (2*sin((4*t(jj))/3))/15);
   dry(jj,1)=0.3*( (2*cos(2*t(jj)))/25 - (2*cos((4*t(jj))/3))/25);
   drz(jj,1)=0;
   ddrx(jj,1)=0.3*(- (4*cos(2*t(jj)))/25 - (8*cos((4*t(jj))/3))/45);
   ddry(jj,1)=0.3*((8*sin((4*t(jj))/3))/75 - (4*sin(2*t(jj)))/25);
   ddrz(jj,1)=0;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end
%--Errors-
erposx=rx-posx;
erposy=ry-posy;
erposz=rz-posz;
erdposx=drx-dposx;
erdposy=dry-dposy;
erdposz=drz-dposz;
erddposx=ddrx-ddposx;
erddposy=ddry-ddposy;
erddposz=ddrz-ddposz;

save mavn_SRDdata1 t qAll dqAll ddqAll uAll posx posy posz dposx dposy dposz ddposx ddposy ddposz;
save mavn_SRDdata2 erposx erposy erposz erdposx erdposy erdposz erddposx erddposy erddposz;
save mavn_SRDdata3 j2px j3px j4px j5px j2py j3py j4py j5py j2pz j3pz j4pz j5pz rx ry rz;
