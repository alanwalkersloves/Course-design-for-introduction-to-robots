
clc;
clear all
close all
format long;
global q0 T iec;


T=20;
q0=[0;pi/4;0;pi/2;-pi/4;0];
% q0=[-0.1;-1.1;-1;0.1;0.5;0.5];
%q0=[3.06147011763390,4.91919437438584,1.15856762876936,-1.76838518750552,1.865185438670004,2.65270000000000]';
global ec eta m n gamma;
ec=3;
iec=12;
n=6;
m=3;
gamma=1e3;
eta=1e3;
dq0=zeros(n,1);
[J0,DJ0]=jdj(q0,dq0);
yye0=zeros(n+ec+iec,1);
u0=[dq0;0.001*ones(ec+iec,1)];
init=[q0;u0;yye0];%acutally, abitrary initial y0
options=odeset();

tic;
[t,y]=ode15s('mpt_net',[0,T],init,options);%ode15s much better than ode45
cpu_time=toc;
%save cpu_time to "txt" file
fid=fopen('mvtn_cost_time.txt','a');
fprintf(fid,'Computing cost time: %g\n',cpu_time);
fclose(fid);
save mavn_SYSdata q0 eta T m gamma n;
save mavn_INITdata t y;
