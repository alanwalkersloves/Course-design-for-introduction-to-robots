function output=AFMball(E)


    if norm(E)>1.3
       E = 1.3*(E./norm(E));
    end

 output=E;

end
