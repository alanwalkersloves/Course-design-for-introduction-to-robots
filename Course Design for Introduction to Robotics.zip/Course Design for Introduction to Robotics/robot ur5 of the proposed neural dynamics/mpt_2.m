

clear;
format long;
load mavn_SYSdata;
load mavn_INITdata;

interval=0.025;
jj=0;
epsilon=0;
for ii=1:length(t)
    if(t(ii,1)>=epsilon)
        jj=jj+1;
        tn(jj,1)=t(ii,1);
        yn(jj,:)=y(ii,:);
        epsilon=jj*interval;        
    elseif(ii==length(t))
        jj=jj+1;
        tn(jj,1)=t(ii,1);
        yn(jj,:)=y(ii,:);
        epsilon=jj*interval;
    end
end
clear t y;
t=tn;
y=yn;
size(t)
size(y)
clear tn yn;
qAll=y(:,1:n);
size(qAll)
dqAll=y(:,(n+1):(2*n));
size(dqAll)
uAll=y(:,(2*n+1):(3*n+m));
size(uAll)
ddqAll=uAll(:,1:n);
size(ddqAll)
%%%%%%%%%%%%%%%%%%%%
i=1;
for jj=1:4:length(t)
    qq(i,:)=qAll(jj,:);
    i=i+1;
end
%%%%%%%%%%%%%%%%%%%
save mavn_SNDdata t qAll dqAll uAll ddqAll;