function output=AFMbound(E)


upper_bound=1;
lower_bound=-1;
output=zeros(size(E));

for i=1:length(E)
    if E(i)>upper_bound
       E(i) = upper_bound;
    end
    if E(i)<lower_bound
        E(i) = lower_bound;
    end
end
for i=1:length(E)
   
     
        output(i) =E(i);
   
end
