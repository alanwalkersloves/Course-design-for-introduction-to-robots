
clear;
format long;
load mavn_SYSdata;
load mavn_SRDdata1;
load mavn_SRDdata2;
load mavn_SRDdata3;

figure;%14
plot3(posx,posy,posz,'g--','linewidth',1);hold on;
for j=1:15:length(t)
    linksX=[0;0;j2px(j);j3px(j);j4px(j);j5px(j);posx(j)];
    linksY=[0;0;j2py(j);j3py(j);j4py(j);j5py(j);posy(j)];
    linksZ=[-0.2;0;j2pz(j);j3pz(j);j4pz(j);j5pz(j);posz(j)];
    plot3(linksX,linksY,linksZ,'k');hold on;
end
xlabel('X');ylabel('Y');zlabel('Z');
grid on;
set(gca,'drawmode','fast');

figure;%15
plot3(posx,posy,posz, 'LineWidth',2);hold on;
for j=1:length(t)
    basejoint1=line('xdata',[0;0],'ydata',[0;0],'zdata',[-0.2;0],...
        'color', 'yellow','erasemode','none');
    joints12=line('xdata',[0;j2px(j)],'ydata',[0;j2py(j)],'zdata',[0;j2pz(j)],...
        'color', 'red','erasemode','none');
    joints23=line('xdata',[j2px(j);j3px(j)],'ydata',[j2py(j);j3py(j)],'zdata',[j2pz(j);j3pz(j)],...
        'color', 'cyan','erasemode','none');
    joints34=line('xdata',[j3px(j);j4px(j)],'ydata',[j3py(j);j4py(j)],'zdata',[j3pz(j);j4pz(j)],...
        'color', 'magenta','erasemode','none');
    joints45=line('xdata',[j4px(j);j5px(j)],'ydata',[j4py(j);j5py(j)],'zdata',[j4pz(j);j5pz(j)],...
        'color', 'blue','erasemode','none');
    joints56=line('xdata',[j5px(j);posx(j)],'ydata',[j5py(j);posy(j)],'zdata',[j5pz(j);posz(j)],...
        'color', 'green','erasemode','none');
    drawnow
end
xlabel('X');ylabel('Y');zlabel('Z');
grid on;
