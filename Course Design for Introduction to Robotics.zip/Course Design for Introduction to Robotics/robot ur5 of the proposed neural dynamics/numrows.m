% The function returns the number of rows in the matrix m
function r = numrows(m)
	r= size(m);
