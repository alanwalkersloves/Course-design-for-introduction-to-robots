function y=AFMlinear(E)

y=E;